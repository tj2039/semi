package com.mystudy.serv.pd;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mystudy.pd.model.PdDAO;
import com.mystudy.pd.model.PdDTO;


//@WebServlet("/EditServlet")
public class EditServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//응답 문서에 대한 ContentType지정
		response.setContentType("text/html;charset=euc-kr");
		
		//브라우저에 출력할 출력 스트림 얻어오기
		PrintWriter out=response.getWriter();
		
		//1
		String no=request.getParameter("no");
		//2 db작업
		PdDAO pdDao=new PdDAO();
		PdDTO dto=null;
		
		try {
			dto=pdDao.selectByNo(Integer.parseInt(no));
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//3.결과처리
		out.print("<form name='frmEdit' method='POST' action='/mystudy/Edit_okServ'>");
		out.print("<INPUT TYPE=\"hidden\" NAME=\"no\" value="+no+"><br>");
		out.print("상품명: <INPUT TYPE=\"text\" NAME=\"pdName\" value="+dto.getPdName()+"><br>");
		out.print("가격:<INPUT TYPE=\"text\" NAME=\"price\" value="+dto.getPrice()+"><br><br>");
		out.print("<INPUT TYPE=\"submit\" value=\"등록\">");
		out.print("<INPUT TYPE=\"reset\" value=\"취소\">");
		out.print("</form>");
		out.close();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
