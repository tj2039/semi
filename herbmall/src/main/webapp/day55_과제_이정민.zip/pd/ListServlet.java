package com.mystudy.serv.pd;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mystudy.pd.model.PdDAO;
import com.mystudy.pd.model.PdDTO;


//@WebServlet("/ListServ")
public class ListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//응답 문서에 대한 ContentType 지정
		response.setContentType("text/html;charset=euc-kr");
		
		//브라우저에 출력할 출력 스트림 얻어오기
		PrintWriter out = response.getWriter();
		
		//1. 		
		//2. db작업
		PdDAO pdDao = new PdDAO();
		List<PdDTO> list=null;
		try {
			list=pdDao.selectAll();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		//3. 결과처리
		DecimalFormat df = new DecimalFormat("#,###");
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		out.print("<html>");
		out.print("<head><title>상품 목록 페이지</title></head>");
		out.print("<body>");
		out.print("<h1>상품 목록</h1>");
		out.print("<table border='1' style='width:500px'>");
		out.print("<tr><th>번호</th>");
		out.print("<th>상품명</th>");
		out.print("<th>가격</th>");
		out.print("<th>등록일</th>");
		out.print("</tr>");
		//반복시작
		for(int i=0;i<list.size();i++) {
			PdDTO dto=list.get(i);
			out.print("<tr>");
			out.print("<td style='text-align:center'>"+dto.getNo()+"</td>");
			out.print("<td><a href='/mystudy/DetailServ?no="
					+dto.getNo()+"'> "
					+dto.getPdName()+"</a></td>");
			out.print("<td style='text-align:right'>"+df.format(dto.getPrice())+"원 </td>");
			out.print("<td style='text-align:center'>"+sdf.format(dto.getRegdate())+"</td>");
			out.print("</tr>");
		}//for
		
		out.print("</table>");
		out.print("</body>");		
		out.print("</html>");
		out.print("<hr><a href='/mystudy/sersvTest/registerPd.html'>"
				+ "상품등록</a>");
		out.close();
		
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
	}

}
