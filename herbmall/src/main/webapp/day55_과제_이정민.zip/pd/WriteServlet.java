package com.mystudy.serv.pd;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mystudy.pd.model.PdDAO;
import com.mystudy.pd.model.PdDTO;


@WebServlet("/WriteServ")
public class WriteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//
		response.setContentType("text/html;charset=euc-kr");
		PrintWriter out=response.getWriter();
		//post
		request.setCharacterEncoding("euc-kr");
		
		//1.
		String pdName=request.getParameter("pdName");
		String price=request.getParameter("price");
		//2.
		PdDAO pdDao=new PdDAO();
		PdDTO dto=new PdDTO();
		dto.setPdName(pdName);
		dto.setPrice(Integer.parseInt(price));
		try {
			int cnt=pdDao.insertPd(dto);
			
			//3.
			if(cnt>0) {
				response.sendRedirect("/mystudys");
			}else {
				System.out.println("상품 등록 실패!");
				response.sendRedirect("/mystudy/servTest/registerPd.html");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
	}

}
